
import { GoogleGenAI } from "@google/genai";
import { AttendanceSession, ClassRoom } from "../types";

export const getAttendanceInsights = async (
  session: AttendanceSession,
  classRoom: ClassRoom
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  
  const presentCount = session.records.filter(r => r.status === 'present').length;
  const absentCount = session.records.filter(r => r.status === 'absent').length;
  const lateCount = session.records.filter(r => r.status === 'late').length;

  const prompt = `
    As a classroom teaching assistant, provide a brief (2-3 sentences) insight based on today's attendance data for class "${classRoom.name}".
    
    Data:
    - Total Students: ${classRoom.students.length}
    - Present: ${presentCount}
    - Absent: ${absentCount}
    - Late: ${lateCount}
    
    The absences were: ${session.records.filter(r => r.status === 'absent').map(r => {
      const s = classRoom.students.find(st => st.id === r.studentId);
      return s ? s.name : 'Unknown';
    }).join(', ')}.
    
    Focus on potential trends or students who might need attention.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "No insights available at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Failed to generate AI insights.";
  }
};
