
import React, { useState, useEffect } from 'react';
import { MOCK_CLASSES } from '../constants';
import { AttendanceRecord, ClassRoom, AttendanceSession } from '../types';
import { syncToGoogleSheets } from '../services/sheetsService';
import { getAttendanceInsights } from '../services/geminiService';

const AttendanceTracker: React.FC = () => {
  const [selectedClass, setSelectedClass] = useState<ClassRoom>(MOCK_CLASSES[0]);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);

  // Initialize records on class change
  useEffect(() => {
    const initialRecords: AttendanceRecord[] = selectedClass.students.map(s => ({
      studentId: s.id,
      status: 'present',
      timestamp: new Date().toISOString()
    }));
    setRecords(initialRecords);
    setAiInsight(null);
  }, [selectedClass]);

  const updateStatus = (studentId: string, status: 'present' | 'absent' | 'late') => {
    setRecords(prev => prev.map(r => 
      r.studentId === studentId ? { ...r, status, timestamp: new Date().toISOString() } : r
    ));
  };

  const handleSave = async () => {
    setIsSyncing(true);
    setSyncSuccess(false);
    
    const session: AttendanceSession = {
      id: `session-${Date.now()}`,
      classId: selectedClass.id,
      date: new Date().toISOString().split('T')[0],
      records: records
    };

    const success = await syncToGoogleSheets(session);
    if (success) {
      setSyncSuccess(true);
      setTimeout(() => setSyncSuccess(false), 3000);
      
      // Auto-generate AI insight
      setIsGeneratingInsight(true);
      const insight = await getAttendanceInsights(session, selectedClass);
      setAiInsight(insight);
      setIsGeneratingInsight(false);
    }
    setIsSyncing(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Selection Header */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <label className="text-sm font-semibold text-slate-500">Class:</label>
          <select 
            className="flex-1 md:w-64 bg-slate-50 border-none rounded-xl px-4 py-2 font-medium focus:ring-2 focus:ring-indigo-500"
            value={selectedClass.id}
            onChange={(e) => setSelectedClass(MOCK_CLASSES.find(c => c.id === e.target.value) || MOCK_CLASSES[0])}
          >
            {MOCK_CLASSES.map(c => <option key={c.id} value={c.id}>{c.name} - {c.subject}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            onClick={handleSave}
            disabled={isSyncing}
            className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-semibold transition-all shadow-lg ${
              syncSuccess ? 'bg-green-500 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95'
            }`}
          >
            {isSyncing ? (
              <><i className="fas fa-spinner animate-spin"></i> Syncing...</>
            ) : syncSuccess ? (
              <><i className="fas fa-check"></i> Saved!</>
            ) : (
              <><i className="fab fa-google-drive"></i> Sync to Sheets</>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Attendance List */}
        <div className="lg:col-span-2 space-y-4">
          {selectedClass.students.map((student) => {
            const record = records.find(r => r.studentId === student.id);
            return (
              <div key={student.id} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between group hover:border-indigo-200 transition-colors">
                <div className="flex items-center gap-4">
                  <img src={student.avatar} className="w-12 h-12 rounded-full border shadow-sm" alt="" />
                  <div>
                    <h4 className="font-bold text-slate-800">{student.name}</h4>
                    <p className="text-xs text-slate-500">{student.email}</p>
                  </div>
                </div>
                
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  {(['present', 'absent', 'late'] as const).map((status) => (
                    <button
                      key={status}
                      onClick={() => updateStatus(student.id, status)}
                      className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                        record?.status === status 
                          ? status === 'present' ? 'bg-emerald-500 text-white shadow-md' 
                          : status === 'absent' ? 'bg-rose-500 text-white shadow-md'
                          : 'bg-amber-500 text-white shadow-md'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Sidebar Insights */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <i className="fas fa-robot text-indigo-500"></i>
              AI Assistant
            </h3>
            
            {isGeneratingInsight ? (
              <div className="flex flex-col items-center justify-center py-8 text-slate-400">
                <i className="fas fa-circle-notch animate-spin text-2xl mb-2"></i>
                <p className="text-sm">Analyzing attendance patterns...</p>
              </div>
            ) : aiInsight ? (
              <div className="space-y-4">
                <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 italic text-indigo-900 text-sm leading-relaxed">
                   "{aiInsight}"
                </div>
                <button 
                  onClick={() => handleSave()}
                  className="w-full py-2 text-xs font-bold text-indigo-600 hover:bg-indigo-50 rounded-lg uppercase tracking-widest border border-indigo-100 transition-colors"
                >
                  Refresh Insights
                </button>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                  <i className="fas fa-sparkles text-2xl"></i>
                </div>
                <p className="text-sm text-slate-400 px-4">Save attendance to generate automated classroom insights.</p>
              </div>
            )}
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-6 rounded-2xl shadow-lg text-white">
            <h4 className="font-bold mb-2">Pro Tip</h4>
            <p className="text-sm text-indigo-100 leading-relaxed">
              Use the <span className="font-bold underline">Camera Mode</span> in settings to quickly scan student IDs and mark them as present automatically!
            </p>
            <button className="mt-4 w-full py-2 bg-white/10 hover:bg-white/20 rounded-xl font-semibold text-sm transition-all">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendanceTracker;
