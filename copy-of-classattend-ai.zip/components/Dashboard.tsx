
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { MOCK_STUDENTS } from '../constants';

const Dashboard: React.FC = () => {
  const data = MOCK_STUDENTS.map(s => ({ name: s.name.split(' ')[0], rate: s.attendanceRate }));
  
  const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#ef4444', '#f59e0b', '#10b981', '#06b6d4'];

  const stats = [
    { label: 'Avg Attendance', value: '88%', icon: 'fa-chart-area', color: 'bg-blue-500' },
    { label: 'Total Students', value: '42', icon: 'fa-users', color: 'bg-indigo-500' },
    { label: 'At Risk', value: '3', icon: 'fa-exclamation-triangle', color: 'bg-rose-500' },
    { label: 'Classes Today', value: '4', icon: 'fa-calendar-day', color: 'bg-emerald-500' },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
            <div>
              <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
              <p className="text-2xl font-bold mt-1">{stat.value}</p>
            </div>
            <div className={`${stat.color} text-white p-3 rounded-xl shadow-lg`}>
              <i className={`fas ${stat.icon} text-xl`}></i>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Attendance Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <i className="fas fa-chart-bar text-indigo-500"></i>
            Student Attendance Rates (%)
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="rate" radius={[6, 6, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Low Attendance List */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <i className="fas fa-user-clock text-rose-500"></i>
            Attention Needed
          </h3>
          <div className="space-y-4">
            {MOCK_STUDENTS.filter(s => s.attendanceRate < 80).map((student) => (
              <div key={student.id} className="flex items-center justify-between p-3 rounded-xl bg-rose-50 border border-rose-100">
                <div className="flex items-center gap-3">
                  <img src={student.avatar} className="w-10 h-10 rounded-full bg-white shadow-sm" alt="" />
                  <div>
                    <p className="text-sm font-semibold text-rose-900">{student.name}</p>
                    <p className="text-xs text-rose-600">{student.attendanceRate}% attendance</p>
                  </div>
                </div>
                <button className="text-rose-500 hover:bg-rose-100 p-2 rounded-lg">
                  <i className="fas fa-envelope"></i>
                </button>
              </div>
            ))}
            <button className="w-full mt-4 py-3 text-sm font-medium text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-xl transition-all">
              View All Students <i className="fas fa-chevron-right ml-1"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
