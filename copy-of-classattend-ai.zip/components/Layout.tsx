
import React from 'react';
import { View } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: View;
  onViewChange: (view: View) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeView, onViewChange }) => {
  const navItems = [
    { id: View.DASHBOARD, icon: 'fa-chart-line', label: 'Dashboard' },
    { id: View.TAKE_ATTENDANCE, icon: 'fa-clipboard-check', label: 'Attendance' },
    { id: View.HISTORY, icon: 'fa-history', label: 'History' },
    { id: View.SETTINGS, icon: 'fa-cog', label: 'Settings' },
  ];

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-indigo-900 text-white flex flex-col shadow-xl z-20">
        <div className="p-6 border-b border-indigo-800 flex items-center gap-3">
          <div className="bg-white text-indigo-900 p-2 rounded-lg">
            <i className="fas fa-graduation-cap text-xl"></i>
          </div>
          <h1 className="font-bold text-xl tracking-tight">ClassAttend</h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeView === item.id 
                  ? 'bg-indigo-700 text-white shadow-lg' 
                  : 'text-indigo-100 hover:bg-indigo-800'
              }`}
            >
              <i className={`fas ${item.icon} w-5`}></i>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-indigo-800">
          <div className="flex items-center gap-3 mb-4">
            <img src="https://picsum.photos/seed/admin/40" className="w-10 h-10 rounded-full border-2 border-indigo-400" />
            <div>
              <p className="text-sm font-semibold">Prof. Johnson</p>
              <p className="text-xs text-indigo-300">Admin</p>
            </div>
          </div>
          <button className="w-full py-2 px-4 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg text-sm transition-colors">
            <i className="fas fa-sign-out-alt mr-2"></i> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto relative">
        <header className="h-16 bg-white border-b sticky top-0 z-10 flex items-center justify-between px-8">
          <h2 className="text-xl font-semibold capitalize text-slate-800">
            {activeView.replace('_', ' ')}
          </h2>
          <div className="flex items-center gap-4">
            <div className="bg-slate-100 px-3 py-1.5 rounded-full flex items-center gap-2 text-sm text-slate-600">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
              Google Sheets Connected
            </div>
          </div>
        </header>
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
